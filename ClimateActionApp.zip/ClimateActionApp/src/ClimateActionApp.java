//package climateactionapp;

/**
 * Main application class for Climate Action App
 * @author Kamlesh
 */
public class ClimateActionApp {
    public static void main(String[] args) {
        ClimateActionGUI mainGUI = new ClimateActionGUI();
        mainGUI.setVisible(true);
    }
}