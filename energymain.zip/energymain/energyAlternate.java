/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package energymain;

/**
 *
 * @author Cam
 */
public class energyAlternate extends Energy {
    private String[] suggestions;   // list of alternative suggestions
    private int count;              // how many suggestions added

    public energyAlternate() {
        suggestions = new String[10];   // max 10 suggestions
        count = 0;
    }

    // Add a suggestion
    public void addSuggestion(String suggestion) {
        if (count < suggestions.length) {
            suggestions[count] = suggestion;
            count++;
        }
    }

    // Auto-generate some default suggestions
    public void generateDefaultSuggestions() {
        addSuggestion("Use LED light bulbs instead of incandescent.");
        addSuggestion("Unplug chargers when not in use.");
        addSuggestion("Run washing machine at lower temperatures.");
        addSuggestion("Turn off appliances fully instead of standby mode.");
    }

    // Return all suggestions as a string for GUI display
    public String getAllSuggestions() {
        String info = "";

        for (int i = 0; i < count; i++) {
            info += "- " + suggestions[i] + "\n";
        }

        return info;
    }

}
