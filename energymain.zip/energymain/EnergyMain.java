/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package energymain;

import javax.swing.JOptionPane;

/**
 *
 * @author Cam
 */
public class EnergyMain {
    public static void main(String[] args) {
        energyCalculator calc = new energyCalculator();
        boolean repeat = true;

        while (repeat) {
            String device = JOptionPane.showInputDialog(null, "Enter device name: ");
            if (device == null || device.isEmpty()){
                JOptionPane.showMessageDialog(null, "Device name cannot be empty.");
                continue;
            }

            // Get kWh used
            String kwhInput = JOptionPane.showInputDialog(null, "Enter kilowatts used: ");
            double killowatts = Double.parseDouble(kwhInput);

            // Get time in hours
            String timeInput = JOptionPane.showInputDialog(null, "Enter time used (hours):");
            int time = Integer.parseInt(timeInput);

            // Add data to the calculator arrays
            calc.addDeviceData(device, killowatts, time);

            // Ask if user wants to add more
            String input = JOptionPane.showInputDialog(null, "Add another device? (Y/N)");

            if (input.equalsIgnoreCase("N")) {
                repeat = false;
            }
        }

        // Ask for cost per kWh
        String rateInput = JOptionPane.showInputDialog(null, "Enter cost per kWh: ");
        double rate = Double.parseDouble(rateInput);

        // Calculate totals
        double totalKwh = calc.getTotalKwh();
        calc.setKillowatts(totalKwh);
        calc.setTime(1); // simple placeholder to reuse computeCost()
        double totalCost = calc.computeCost(rate);

        // Show results
        String summary = "Total Energy Usage: " + totalKwh + " kWh\n"
                + "Total Cost: €" + String.format("%.2f", totalCost);

        JOptionPane.showMessageDialog(null, summary);
    }

}
    

